# New Plants vs. Zombies JavaScript

![Logo.png](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c57c4bb8d56c4282894981a56ced6bca~tplv-k3u1fbpfcp-jj-mark:0:0:0:0:q75.image#?w=900&h=600&s=763723&e=png&b=e5d7bf)

*New Plants vs. Zombies JavaScript* is an open-source PvZ fan-made game produced by [JiangNanGame](http://www.jiangnangame.com).

It's the earliest web PvZ fan-made game by JiangNanGame, developed from 2015 to 2016. **So there are many bugs in this game.**

If you are an ordinary player who wants to play this project, we hope you can **give it up** and turn to our latest PvZ fan-made game *[Plants vs. Zombies Travel](https://angel-shadow.itch.io/pvz-travel)*, which will bring you the best gaming experience.

If you are a programming learner who wants to learn how to develop a web game through this project, we hope you can **give it up** and turn to our latest open-source PvZ fan-made game *[The Open Source Version Of PvZ Travel](https://github.com/jiangnangame/PvZ_TR_CODE)*, which has fewer bugs and more programming-compliant code.
