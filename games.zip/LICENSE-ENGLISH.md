<center><h1>The Changjiang River License</h1></center>
<center><h2> Version 3, July, 2020 </h2></center>

Hello! When you see this text, it means that you are using an open source work protected by the The Changjiang River License. 

In order to protect the rights of developers of the work, you must abide by the requirements of this license when you use, copy, modify and publish it for the second time.

### I. Definitions ###
1."The License" means *The Changjiang River License*.

2."The work" means the whole and any partial content of the open source work that is protected by the license.

3."The author" means the natural or legal person who creates and distributes the work.

4."The user" means the natural or legal person who uses, copies, modifies, and republishes the work.

5."The secondly modified works" means the products of the user's second modification and creation of the work.

6."Secondary release" means the behavior of the user to publish the second modified works and use them to produce other materials.

### II. The Rights Of User ###

1.For non-profit purposes, the user can use, copy and modify the work.

2.For non-profit purposes, the user can secondary release the modified works and decide to open its source or not.

### III. The Obligations Of User ###

1.The user shall not apply the work directly or indirectly for any profitable purpose.

2.The user must always keep the copy of the license, the production team list, the disclaimer and other important information in the work complete.

3.When promoting and publishing the secondly modified works, the user must indicate the copyright information such as the author in the promotional materials.

4.When opening the source of the secondly modified works, the user must continue to use the license for it.

5.The user shall not dissect a part of the work separately for other projects.

### IV. Punishments ###

1.If the user violates any of the provisions of the lisence, all rights granted in the lisence will be automatically revoked. The author also has the right to pursue legal responsibility.

### V. Other Instructions ###

1.[JiangNanGame](http://www.jiangnangame.com) has the right to update the specific content of the license. After the license is updated, all works adopting the license will be deemed to be automatically replaced with the latest version of the license.

2.Users should be aware that there may be defects in the work. The author is not responsible for any losses caused by these defects.

3.The license does not provide users with any authorization of the brand intellectual property rights of the work. These rights belong to the author.